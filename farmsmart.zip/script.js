/* ========================================
   FARMSMART – COMPLETE JAVASCRIPT
   Covers: Clock, Weather, Market Prices,
   Seeds, Crops, Pests, Water, Farmer,
   AI Chatbot, Language Switching
   ======================================== */

// ===== LANGUAGE DATA =====
const LANG = {
  en: {
    nav_soil:"Soil", nav_crop:"Crops", nav_seeds:"Seeds", nav_weather:"Weather",
    nav_pest:"Pest", nav_water:"Water", nav_market:"Market", nav_farmer:"Farmer",
    hero_tag:"Smart Agricultural Platform", hero_title:"Grow Smarter.\nHarvest Better.",
    hero_sub:"Identify the right seeds for your soil, track live prices, get weather updates and AI-powered farming guidance.",
    hero_btn1:"Segregate Seeds", hero_btn2:"Live Market Prices",
    stat1:"Crop Varieties", stat2:"Soil Types", stat3:"Wheat/Qtl (Live)",
    weather_title:"Live Weather", market_title:"Live Market Prices",
    soil_quick_title:"Quick Soil Check", soil_quick_desc:"Select your soil type to see best crops:",
    soil_sandy:"🏜️ Sandy", soil_clay:"🧱 Clay", soil_loamy:"🌱 Loamy", soil_black:"⚫ Black",
    soil_tag:"SOIL SYSTEM", soil_h2:"Know Your Soil",
    soil_p:"Understanding your soil type is the foundation of successful farming.",
    seed_tag:"SEED SEGREGATION", seed_h2:"Find the Right Seed for Your Land",
    seed_p:"Filter seeds based on your soil type, season, and water availability.",
    filter_soil:"Soil Type", filter_season:"Season", filter_water:"Water Need",
    filter_type:"Type", filter_search:"Search", all:"All",
    weather_advice_sunny:"☀️ Good weather for fieldwork. Irrigate early morning to avoid evaporation.",
    weather_advice_rain:"🌧️ Rain expected. Hold off on pesticide spraying. Check drainage channels.",
    weather_advice_cloud:"⛅ Overcast skies. Good conditions for transplanting seedlings.",
    crop_tag:"CROP PRODUCTION", crop_h2:"Crop Production Guide",
    pest_tag:"PEST & DISEASE", pest_h2:"Pest & Disease Management",
    pest_p:"Early identification and proper treatment saves your harvest.",
    pesticide_h:"Pesticide & Medicine Guide",
    pest_warn:"Excessive use of pesticides damages soil health, kills beneficial insects, and leaves harmful residues in food. Always follow recommended doses.",
    water_tag:"WATER MANAGEMENT", water_h2:"Water Scarcity Solutions",
    mkt_tag:"MARKET PRICES", mkt_h2:"Live Market & Selling Prices",
    mkt_p:"Track real-time commodity prices, MSP rates, and plan your selling strategy.",
    farmer_tag:"FARMER PROFILES", farmer_h2:"Farmer Details & Registration",
    farmer_reg:"Register Farmer", farmer_list:"Registered Farmers",
    footer_about:"Empowering farmers with smart technology, data-driven insights, and AI assistance.",
    footer_copy:"© 2025 FarmSmart. Built for Indian Farmers.",
    market_note:"* Prices are indicative. Check local mandi for exact rates."
  },
  hi: {
    nav_soil:"मिट्टी", nav_crop:"फसलें", nav_seeds:"बीज", nav_weather:"मौसम",
    nav_pest:"कीट", nav_water:"जल", nav_market:"बाज़ार", nav_farmer:"किसान",
    hero_tag:"स्मार्ट कृषि प्लेटफ़ॉर्म", hero_title:"समझदारी से उगाएं।\nबेहतर फसल काटें।",
    hero_sub:"अपनी मिट्टी के लिए सही बीज पहचानें, लाइव कीमतें देखें, मौसम अपडेट पाएं।",
    hero_btn1:"बीज चुनें", hero_btn2:"लाइव बाज़ार मूल्य",
    stat1:"फसल किस्में", stat2:"मिट्टी के प्रकार", stat3:"गेहूं/क्विंटल (लाइव)",
    weather_title:"लाइव मौसम", market_title:"लाइव बाज़ार मूल्य",
    soil_quick_title:"त्वरित मिट्टी जांच", soil_quick_desc:"बेस्ट फसल देखने के लिए मिट्टी का प्रकार चुनें:",
    soil_sandy:"🏜️ रेतीली", soil_clay:"🧱 चिकनी", soil_loamy:"🌱 दोमट", soil_black:"⚫ काली",
    soil_tag:"मिट्टी प्रणाली", soil_h2:"अपनी मिट्टी जानें",
    soil_p:"मिट्टी का प्रकार समझना सफल खेती की नींव है।",
    seed_tag:"बीज पृथक्करण", seed_h2:"अपनी भूमि के लिए सही बीज खोजें",
    seed_p:"मिट्टी के प्रकार, मौसम और जल उपलब्धता के आधार पर बीज फ़िल्टर करें।",
    filter_soil:"मिट्टी का प्रकार", filter_season:"मौसम", filter_water:"पानी की ज़रूरत",
    filter_type:"प्रकार", filter_search:"खोजें", all:"सभी",
    market_note:"* कीमतें सांकेतिक हैं। सटीक दरों के लिए स्थानीय मंडी से जांचें।"
  },
  ta: {
    nav_soil:"மண்", nav_crop:"பயிர்கள்", nav_seeds:"விதைகள்", nav_weather:"வானிலை",
    nav_pest:"பூச்சி", nav_water:"நீர்", nav_market:"சந்தை", nav_farmer:"விவசாயி",
    hero_tag:"ஸ்மார்ட் வேளாண் தளம்", hero_title:"புத்திசாலியாக விளையுங்கள்.\nசிறப்பாக அறுவடை செய்யுங்கள்.",
    hero_sub:"உங்கள் நிலத்திற்கு சரியான விதைகளை கண்டறியுங்கள், நேரடி விலைகளை கண்காணியுங்கள்.",
    hero_btn1:"விதைகளை பிரி", hero_btn2:"நேரடி சந்தை விலைகள்",
    stat1:"பயிர் வகைகள்", stat2:"மண் வகைகள்", stat3:"கோதுமை/குவிண்டால்",
    weather_title:"நேரடி வானிலை", market_title:"நேரடி சந்தை விலைகள்",
    soil_quick_title:"விரைவான மண் சரிபார்ப்பு", soil_quick_desc:"சிறந்த பயிர்களை பார்க்க மண் வகையை தேர்ந்தெடுக்கவும்:",
    soil_sandy:"🏜️ மணல்", soil_clay:"🧱 களிமண்", soil_loamy:"🌱 வண்டல்", soil_black:"⚫ கருப்பு",
    soil_tag:"மண் அமைப்பு", soil_h2:"உங்கள் மண்ணை அறியுங்கள்",
    soil_p:"மண் வகையைப் புரிந்துகொள்வது வெற்றிகரமான விவசாயத்தின் அடித்தளம்.",
    seed_tag:"விதை பிரித்தல்", seed_h2:"உங்கள் நிலத்திற்கு சரியான விதையை கண்டறியுங்கள்",
    seed_p:"மண் வகை, பருவகாலம் மற்றும் நீர் கிடைக்கும் தன்மையின் அடிப்படையில் விதைகளை வடிகட்டவும்.",
    filter_soil:"மண் வகை", filter_season:"பருவகாலம்", filter_water:"நீர் தேவை",
    filter_type:"வகை", filter_search:"தேடல்", all:"அனைத்தும்",
    market_note:"* விலைகள் சுட்டிக்காட்டல் மட்டுமே. சரியான விலைக்கு உள்ளூர் மண்டியை சரிபார்க்கவும்."
  },
  te: {
    nav_soil:"నేల", nav_crop:"పంటలు", nav_seeds:"విత్తనాలు", nav_weather:"వాతావరణం",
    nav_pest:"పురుగు", nav_water:"నీరు", nav_market:"మార్కెట్", nav_farmer:"రైతు",
    hero_tag:"స్మార్ట్ వ్యవసాయ వేదిక",
    hero_title:"తెలివిగా పెరగండి.\nమెరుగ్గా పండించండి.",
    hero_sub:"మీ నేలకు సరైన విత్తనాలను గుర్తించండి, లైవ్ ధరలను ట్రాక్ చేయండి.",
    hero_btn1:"విత్తనాలు వేరుచేయండి", hero_btn2:"లైవ్ మార్కెట్ ధరలు",
    stat1:"పంట రకాలు", stat2:"నేల రకాలు", stat3:"గోధుమ/క్వింటాల్",
    weather_title:"లైవ్ వాతావరణం", market_title:"లైవ్ మార్కెట్ ధరలు",
    soil_quick_title:"త్వరిత నేల తనిఖీ", soil_quick_desc:"ఉత్తమ పంటలు చూడటానికి నేల రకాన్ని ఎంచుకోండి:",
    soil_sandy:"🏜️ ఇసుక", soil_clay:"🧱 సీమ", soil_loamy:"🌱 మెట్ట", soil_black:"⚫ నల్ల",
    soil_tag:"నేల వ్యవస్థ", soil_h2:"మీ నేలను తెలుసుకోండి",
    soil_p:"నేల రకాన్ని అర్థం చేసుకోవడం విజయవంతమైన వ్యవసాయానికి పునాది.",
    seed_tag:"విత్తన వేరీకరణ", seed_h2:"మీ భూమికి సరైన విత్తనం కనుగొనండి",
    seed_p:"నేల రకం, సీజన్ మరియు నీటి లభ్యత ఆధారంగా విత్తనాలను ఫిల్టర్ చేయండి.",
    filter_soil:"నేల రకం", filter_season:"సీజన్", filter_water:"నీటి అవసరం",
    filter_type:"రకం", filter_search:"వెతుకు", all:"అన్నీ",
    market_note:"* ధరలు సూచనప్రాయంగా మాత్రమే. ఖచ్చితమైన రేట్లకు స్థానిక మండి తనిఖీ చేయండి."
  },
  kn: {
    nav_soil:"ಮಣ್ಣು", nav_crop:"ಬೆಳೆಗಳು", nav_seeds:"ಬೀಜಗಳು", nav_weather:"ಹವಾಮಾನ",
    nav_pest:"ಕೀಟ", nav_water:"ನೀರು", nav_market:"ಮಾರುಕಟ್ಟೆ", nav_farmer:"ರೈತ",
    hero_tag:"ಸ್ಮಾರ್ಟ್ ಕೃಷಿ ವೇದಿಕೆ",
    hero_title:"ಬುದ್ಧಿವಂತಿಕೆಯಿಂದ ಬೆಳೆಸಿ.\nಉತ್ತಮವಾಗಿ ಕೊಯ್ಲು ಮಾಡಿ.",
    hero_sub:"ನಿಮ್ಮ ಮಣ್ಣಿಗೆ ಸರಿಯಾದ ಬೀಜಗಳನ್ನು ಗುರುತಿಸಿ, ಲೈವ್ ಬೆಲೆಗಳನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಿ.",
    hero_btn1:"ಬೀಜ ವಿಂಗಡಿಸಿ", hero_btn2:"ಲೈವ್ ಮಾರುಕಟ್ಟೆ ಬೆಲೆಗಳು",
    stat1:"ಬೆಳೆ ತಳಿಗಳು", stat2:"ಮಣ್ಣಿನ ವಿಧಗಳು", stat3:"ಗೋಧಿ/ಕ್ವಿಂಟಾಲ್",
    weather_title:"ಲೈವ್ ಹವಾಮಾನ", market_title:"ಲೈವ್ ಮಾರುಕಟ್ಟೆ ಬೆಲೆಗಳು",
    soil_quick_title:"ತ್ವರಿತ ಮಣ್ಣು ಪರಿಶೀಲನೆ", soil_quick_desc:"ಅತ್ಯುತ್ತಮ ಬೆಳೆಗಳನ್ನು ನೋಡಲು ಮಣ್ಣಿನ ಪ್ರಕಾರ ಆಯ್ಕೆ ಮಾಡಿ:",
    soil_sandy:"🏜️ ಮರಳು", soil_clay:"🧱 ಜೇಡಿ", soil_loamy:"🌱 ಮೆಕ್ಕಲು", soil_black:"⚫ ಕಪ್ಪು",
    soil_tag:"ಮಣ್ಣಿನ ವ್ಯವಸ್ಥೆ", soil_h2:"ನಿಮ್ಮ ಮಣ್ಣನ್ನು ತಿಳಿಯಿರಿ",
    soil_p:"ಮಣ್ಣಿನ ಪ್ರಕಾರವನ್ನು ಅರ್ಥಮಾಡಿಕೊಳ್ಳುವುದು ಯಶಸ್ವಿ ಕೃಷಿಯ ಆಧಾರ.",
    seed_tag:"ಬೀಜ ವಿಂಗಡಣೆ", seed_h2:"ನಿಮ್ಮ ಭೂಮಿಗೆ ಸರಿಯಾದ ಬೀಜ ಕಂಡುಕೊಳ್ಳಿ",
    seed_p:"ಮಣ್ಣಿನ ಪ್ರಕಾರ, ಋತು ಮತ್ತು ನೀರಿನ ಲಭ್ಯತೆಯ ಆಧಾರದ ಮೇಲೆ ಬೀಜಗಳನ್ನು ಫಿಲ್ಟರ್ ಮಾಡಿ.",
    filter_soil:"ಮಣ್ಣಿನ ಪ್ರಕಾರ", filter_season:"ಋತು", filter_water:"ನೀರಿನ ಅಗತ್ಯ",
    filter_type:"ಪ್ರಕಾರ", filter_search:"ಹುಡುಕಿ", all:"ಎಲ್ಲಾ",
    market_note:"* ಬೆಲೆಗಳು ಸೂಚಕ ಮಾತ್ರ. ನಿಖರ ದರಗಳಿಗೆ ಸ್ಥಳೀಯ ಮಂಡಿಯನ್ನು ಪರಿಶೀಲಿಸಿ."
  },
  mr: {
    nav_soil:"माती", nav_crop:"पिके", nav_seeds:"बियाणे", nav_weather:"हवामान",
    nav_pest:"कीड", nav_water:"पाणी", nav_market:"बाजार", nav_farmer:"शेतकरी",
    hero_tag:"स्मार्ट कृषी व्यासपीठ",
    hero_title:"हुशारीने पिकवा.\nचांगले काढणी करा.",
    hero_sub:"तुमच्या जमिनीसाठी योग्य बियाणे ओळखा, थेट किंमती ट्रॅक करा.",
    hero_btn1:"बियाणे वेगळे करा", hero_btn2:"थेट बाजार किंमती",
    stat1:"पीक वाण", stat2:"माती प्रकार", stat3:"गहू/क्विंटल",
    weather_title:"थेट हवामान", market_title:"थेट बाजार किंमती",
    soil_quick_title:"त्वरित माती तपासणी", soil_quick_desc:"सर्वोत्तम पिके पाहण्यासाठी माती प्रकार निवडा:",
    soil_sandy:"🏜️ वाळू", soil_clay:"🧱 चिकणमाती", soil_loamy:"🌱 चिकणमाती-वाळू", soil_black:"⚫ काळी",
    soil_tag:"माती प्रणाली", soil_h2:"तुमची माती जाणून घ्या",
    soil_p:"माती प्रकार समजणे हे यशस्वी शेतीचा पाया आहे.",
    seed_tag:"बियाणे विभाजन", seed_h2:"तुमच्या जमिनीसाठी योग्य बियाणे शोधा",
    seed_p:"माती प्रकार, हंगाम आणि पाण्याच्या उपलब्धतेनुसार बियाणे फिल्टर करा.",
    filter_soil:"माती प्रकार", filter_season:"हंगाम", filter_water:"पाण्याची गरज",
    filter_type:"प्रकार", filter_search:"शोध", all:"सर्व",
    market_note:"* किंमती सूचक आहेत. अचूक दरांसाठी स्थानिक मंडीशी संपर्क साधा."
  }
};
let currentLang = 'en';

function switchLang(lang) {
  currentLang = lang;
  const t = LANG[lang] || LANG.en;
  document.querySelectorAll('[data-key]').forEach(el => {
    const key = el.getAttribute('data-key');
    if (t[key]) el.textContent = t[key];
  });
}

// ===== LIVE CLOCK =====
function updateClock() {
  const now = new Date();
  document.getElementById('liveClock').textContent = now.toLocaleTimeString('en-IN');
  document.getElementById('liveDate').textContent = now.toLocaleDateString('en-IN', {weekday:'short', day:'numeric', month:'short', year:'numeric'});
}
setInterval(updateClock, 1000);
updateClock();

// ===== MOBILE NAV =====
function toggleNav() {
  document.getElementById('navLinks').classList.toggle('open');
}

// ===== WEATHER SYSTEM =====
const weatherProfiles = [
  { icon:'☀️', desc:'Sunny & Clear', temp:32, humidity:60, wind:12, vis:10, feels:34, rain:0 },
  { icon:'⛅', desc:'Partly Cloudy', temp:28, humidity:72, wind:15, vis:8, feels:29, rain:5 },
  { icon:'🌧️', desc:'Light Rain', temp:24, humidity:88, wind:20, vis:5, feels:23, rain:40 },
  { icon:'⛈️', desc:'Thunderstorm', temp:22, humidity:92, wind:35, vis:3, feels:21, rain:80 },
  { icon:'🌤️', desc:'Mostly Sunny', temp:30, humidity:65, wind:10, vis:10, feels:32, rain:0 },
  { icon:'🌥️', desc:'Overcast', temp:26, humidity:78, wind:18, vis:7, feels:27, rain:20 },
  { icon:'🌈', desc:'Clearing Showers', temp:25, humidity:82, wind:14, vis:9, feels:24, rain:15 }
];
const forecastEmojis = ['☀️','🌤️','⛅','🌧️','🌦️','☀️','⛅'];
const forecastDays = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const forecastTemps = [32,29,26,24,28,31,30];

function initWeather() {
  // Try geolocation
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(pos => {
      fetchWeatherByCoords(pos.coords.latitude, pos.coords.longitude);
    }, () => { loadDemoWeather(); });
  } else { loadDemoWeather(); }
}

function fetchWeatherByCoords(lat, lon) {
  // Demo weather with realistic India-based data
  // In production: use OpenWeatherMap API
  // fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=YOUR_KEY&units=metric`)
  const w = weatherProfiles[Math.floor(Math.random() * weatherProfiles.length)];
  w.temp = Math.round(w.temp + (Math.random()-0.5)*4);
  renderWeather(w, `${lat.toFixed(2)}°N, ${lon.toFixed(2)}°E`);
}

function loadDemoWeather() {
  const w = weatherProfiles[Math.floor(Math.random() * weatherProfiles.length)];
  renderWeather(w, 'Karnataka, India');
}

function renderWeather(w, loc) {
  document.getElementById('weatherIcon').textContent = w.icon;
  document.getElementById('weatherTemp').textContent = `${w.temp}°C`;
  document.getElementById('weatherDesc').textContent = w.desc;
  document.getElementById('weatherLoc').innerHTML = `<i class="fas fa-map-marker-alt"></i> ${loc}`;
  document.getElementById('wHumidity').textContent = `${w.humidity}%`;
  document.getElementById('wWind').textContent = `${w.wind} km/h`;
  document.getElementById('wVis').textContent = `${w.vis} km`;
  document.getElementById('wFeels').textContent = `${w.feels}°C`;

  // Forecast
  const fc = document.getElementById('weatherForecast');
  const today = new Date().getDay();
  fc.innerHTML = forecastDays.slice(0,5).map((d,i) => `
    <div class="forecast-day">
      <div class="f-day">${forecastDays[(today+i)%7]}</div>
      <div class="f-icon">${forecastEmojis[i]}</div>
      <div class="f-temp">${forecastTemps[i]}°</div>
    </div>`).join('');

  // Farming advice
  const t = LANG[currentLang] || LANG.en;
  let advice = t.weather_advice_sunny || '☀️ Good weather for fieldwork.';
  if (w.rain > 30) advice = t.weather_advice_rain || '🌧️ Rain expected. Hold off on spraying.';
  else if (w.rain > 5) advice = t.weather_advice_cloud || '⛅ Overcast. Good for transplanting.';
  document.getElementById('weatherAdvice').textContent = advice;
}

// Refresh weather every 10 minutes
setInterval(initWeather, 600000);

// ===== MARKET PRICES DATA =====
const MARKET_DATA = [
  { name:'Wheat', emoji:'🌾', cat:'cereal', base:2150, msp:2275, unit:'Qtl' },
  { name:'Rice (Paddy)', emoji:'🍚', cat:'cereal', base:2183, msp:2300, unit:'Qtl' },
  { name:'Maize', emoji:'🌽', cat:'cereal', base:1870, msp:2090, unit:'Qtl' },
  { name:'Sorghum (Jowar)', emoji:'🌿', cat:'cereal', base:3180, msp:3371, unit:'Qtl' },
  { name:'Pearl Millet (Bajra)', emoji:'🌿', cat:'cereal', base:2625, msp:2500, unit:'Qtl' },
  { name:'Tur (Arhar)', emoji:'🫘', cat:'pulse', base:7200, msp:7550, unit:'Qtl' },
  { name:'Moong (Green Gram)', emoji:'🫛', cat:'pulse', base:8500, msp:8682, unit:'Qtl' },
  { name:'Urad (Black Gram)', emoji:'🫘', cat:'pulse', base:7200, msp:7400, unit:'Qtl' },
  { name:'Chana (Chickpea)', emoji:'🫘', cat:'pulse', base:5440, msp:5440, unit:'Qtl' },
  { name:'Lentil (Masur)', emoji:'🫘', cat:'pulse', base:5500, msp:6425, unit:'Qtl' },
  { name:'Tomato', emoji:'🍅', cat:'vegetable', base:800, msp:null, unit:'Qtl' },
  { name:'Onion', emoji:'🧅', cat:'vegetable', base:1200, msp:null, unit:'Qtl' },
  { name:'Potato', emoji:'🥔', cat:'vegetable', base:900, msp:null, unit:'Qtl' },
  { name:'Brinjal (Eggplant)', emoji:'🍆', cat:'vegetable', base:600, msp:null, unit:'Qtl' },
  { name:'Cabbage', emoji:'🥬', cat:'vegetable', base:500, msp:null, unit:'Qtl' },
  { name:'Cauliflower', emoji:'🥦', cat:'vegetable', base:700, msp:null, unit:'Qtl' },
  { name:'Groundnut', emoji:'🥜', cat:'oilseed', base:5850, msp:6783, unit:'Qtl' },
  { name:'Soybean', emoji:'🫛', cat:'oilseed', base:4600, msp:4892, unit:'Qtl' },
  { name:'Sunflower', emoji:'🌻', cat:'oilseed', base:5800, msp:7280, unit:'Qtl' },
  { name:'Mustard (Rapeseed)', emoji:'🌼', cat:'oilseed', base:5650, msp:5950, unit:'Qtl' },
  { name:'Cotton (Medium)', emoji:'🌸', cat:'oilseed', base:7020, msp:7121, unit:'Qtl' },
  { name:'Sugarcane', emoji:'🎋', cat:'cereal', base:315, msp:340, unit:'Tonne' },
  { name:'Turmeric', emoji:'🌿', cat:'spice', base:14000, msp:null, unit:'Qtl' },
  { name:'Chilli (Dry)', emoji:'🌶️', cat:'spice', base:9000, msp:null, unit:'Qtl' },
  { name:'Coriander', emoji:'🌿', cat:'spice', base:6500, msp:null, unit:'Qtl' },
  { name:'Garlic', emoji:'🧄', cat:'spice', base:8000, msp:null, unit:'Qtl' },
  { name:'Ginger', emoji:'🫚', cat:'spice', base:7500, msp:null, unit:'Qtl' },
  { name:'Banana', emoji:'🍌', cat:'oilseed', base:1200, msp:null, unit:'Qtl' },
  { name:'Mango', emoji:'🥭', cat:'oilseed', base:2500, msp:null, unit:'Qtl' },
];

let marketPrices = MARKET_DATA.map(item => ({
  ...item,
  current: item.base,
  prev: item.base,
  min: Math.round(item.base * 0.92),
  max: Math.round(item.base * 1.08)
}));

function updateMarketPrices() {
  marketPrices = marketPrices.map(item => {
    const change = (Math.random() - 0.48) * item.base * 0.012;
    const prev = item.current;
    const current = Math.max(item.base * 0.8, Math.min(item.base * 1.2, item.current + change));
    return { ...item, prev, current: Math.round(current) };
  });
}

function renderMarketTable() {
  const top = marketPrices.slice(0, 8);
  const body = document.getElementById('marketBody');
  if (!body) return;
  body.innerHTML = top.map(item => {
    const diff = item.current - item.prev;
    const cls = diff > 0 ? 'price-up' : diff < 0 ? 'price-down' : '';
    const sign = diff > 0 ? '+' : '';
    return `<tr>
      <td>${item.emoji} ${item.name}</td>
      <td><strong>₹${item.current.toLocaleString('en-IN')}</strong></td>
      <td class="${cls}">${sign}${Math.round(diff)}</td>
      <td style="color:#888">₹${item.msp ? item.msp.toLocaleString('en-IN') : '-'}</td>
    </tr>`;
  }).join('');

  // Update ticker
  const ticker = document.getElementById('marketTicker');
  if (ticker) {
    ticker.innerHTML = `<span class="ticker-inner">${marketPrices.map(item => {
      const diff = item.current - item.prev;
      const arrow = diff > 0 ? '▲' : diff < 0 ? '▼' : '●';
      const col = diff > 0 ? '#a5d6a7' : diff < 0 ? '#ef9a9a' : '#fff9c4';
      return `<span style="color:${col}; margin-right:20px;">${item.emoji} ${item.name}: ₹${item.current.toLocaleString('en-IN')} ${arrow}</span>`;
    }).join('')}</span>`;
  }

  // Update hero live price
  const wheat = marketPrices.find(m => m.name === 'Wheat');
  if (wheat) document.getElementById('livePrice').textContent = '₹' + wheat.current.toLocaleString('en-IN');
}

function renderBigMarketTable(filter = '', category = 'all') {
  const body = document.getElementById('bigMarketBody');
  if (!body) return;
  const filtered = marketPrices.filter(item => {
    const matchCat = category === 'all' || item.cat === category;
    const matchSearch = item.name.toLowerCase().includes(filter.toLowerCase());
    return matchCat && matchSearch;
  });
  body.innerHTML = filtered.map(item => {
    const diff = item.current - item.prev;
    const trend = diff > 5 ? '<span class="trend-up">▲ Rising</span>' : diff < -5 ? '<span class="trend-down">▼ Falling</span>' : '<span class="trend-stable">● Stable</span>';
    return `<tr>
      <td><strong>${item.emoji} ${item.name}</strong></td>
      <td>₹${item.min.toLocaleString('en-IN')}</td>
      <td>₹${item.max.toLocaleString('en-IN')}</td>
      <td><strong>₹${item.current.toLocaleString('en-IN')}</strong></td>
      <td>${item.msp ? '₹' + item.msp.toLocaleString('en-IN') : '<span style="color:#aaa">N/A</span>'}</td>
      <td>${trend}</td>
    </tr>`;
  }).join('');
}

function filterMarket() {
  const q = document.getElementById('mktSearch')?.value || '';
  const cat = document.getElementById('mktCategory')?.value || 'all';
  renderBigMarketTable(q, cat);
}

// ===== SEED / CROP DATA =====
const SEEDS = [
  { name:'Rice', emoji:'🍚', type:'cereal', soil:['clay','loamy'], season:'kharif', water:'high', duration:'90-120 days', yield:'40-60 Qtl/acre', price:'₹180-240/kg', spacing:'20×15 cm' },
  { name:'Wheat', emoji:'🌾', type:'cereal', soil:['loamy','clay','black'], season:'rabi', water:'medium', duration:'90-115 days', yield:'40-55 Qtl/acre', price:'₹35-45/kg', spacing:'22.5 cm rows' },
  { name:'Maize', emoji:'🌽', type:'cereal', soil:['loamy','sandy'], season:'kharif', water:'medium', duration:'75-100 days', yield:'25-35 Qtl/acre', price:'₹25-35/kg', spacing:'60×20 cm' },
  { name:'Bajra (Millet)', emoji:'🌿', type:'cereal', soil:['sandy','loamy'], season:'kharif', water:'low', duration:'60-90 days', yield:'10-20 Qtl/acre', price:'₹25-30/kg', spacing:'45×15 cm' },
  { name:'Jowar (Sorghum)', emoji:'🌿', type:'cereal', soil:['black','loamy'], season:'kharif', water:'low', duration:'90-110 days', yield:'15-25 Qtl/acre', price:'₹30-40/kg', spacing:'45×15 cm' },
  { name:'Cotton', emoji:'🌸', type:'cash', soil:['black','loamy'], season:'kharif', water:'medium', duration:'150-180 days', yield:'8-15 Qtl/acre', price:'₹65-75/kg', spacing:'90×60 cm' },
  { name:'Sugarcane', emoji:'🎋', type:'cash', soil:['loamy','black','clay'], season:'perennial', water:'high', duration:'12-18 months', yield:'30-40 Tonne/acre', price:'₹280-320/tonne', spacing:'75 cm rows' },
  { name:'Groundnut', emoji:'🥜', type:'oilseed', soil:['sandy','loamy'], season:'kharif', water:'low', duration:'90-120 days', yield:'10-15 Qtl/acre', price:'₹55-65/kg', spacing:'30×10 cm' },
  { name:'Soybean', emoji:'🫛', type:'oilseed', soil:['black','loamy'], season:'kharif', water:'medium', duration:'90-120 days', yield:'12-18 Qtl/acre', price:'₹45-55/kg', spacing:'45×5 cm' },
  { name:'Sunflower', emoji:'🌻', type:'oilseed', soil:['loamy','black'], season:'rabi', water:'medium', duration:'85-100 days', yield:'8-12 Qtl/acre', price:'₹55-65/kg', spacing:'60×30 cm' },
  { name:'Mustard', emoji:'🌼', type:'oilseed', soil:['loamy','sandy'], season:'rabi', water:'low', duration:'90-110 days', yield:'8-12 Qtl/acre', price:'₹50-60/kg', spacing:'30×10 cm' },
  { name:'Tur (Arhar)', emoji:'🫘', type:'pulse', soil:['black','loamy'], season:'kharif', water:'low', duration:'130-160 days', yield:'6-10 Qtl/acre', price:'₹75-85/kg', spacing:'60×20 cm' },
  { name:'Moong Dal', emoji:'🫛', type:'pulse', soil:['loamy','sandy'], season:'zaid', water:'low', duration:'55-70 days', yield:'4-6 Qtl/acre', price:'₹80-100/kg', spacing:'30×10 cm' },
  { name:'Urad Dal', emoji:'🫘', type:'pulse', soil:['loamy','black'], season:'kharif', water:'low', duration:'65-75 days', yield:'4-7 Qtl/acre', price:'₹70-90/kg', spacing:'30×10 cm' },
  { name:'Chana (Chickpea)', emoji:'🫘', type:'pulse', soil:['loamy','black'], season:'rabi', water:'low', duration:'90-110 days', yield:'8-12 Qtl/acre', price:'₹55-65/kg', spacing:'30×10 cm' },
  { name:'Tomato', emoji:'🍅', type:'vegetable', soil:['loamy','sandy'], season:'rabi', water:'medium', duration:'65-85 days', yield:'80-120 Qtl/acre', price:'₹20-35/kg', spacing:'60×45 cm' },
  { name:'Onion', emoji:'🧅', type:'vegetable', soil:['loamy','black'], season:'rabi', water:'medium', duration:'90-120 days', yield:'80-100 Qtl/acre', price:'₹15-25/kg', spacing:'15×10 cm' },
  { name:'Potato', emoji:'🥔', type:'vegetable', soil:['sandy','loamy'], season:'rabi', water:'medium', duration:'75-100 days', yield:'120-200 Qtl/acre', price:'₹12-20/kg', spacing:'60×20 cm' },
  { name:'Brinjal', emoji:'🍆', type:'vegetable', soil:['loamy','clay'], season:'kharif', water:'medium', duration:'70-90 days', yield:'80-100 Qtl/acre', price:'₹10-20/kg', spacing:'60×45 cm' },
  { name:'Okra (Bhindi)', emoji:'🫑', type:'vegetable', soil:['loamy','sandy'], season:'kharif', water:'medium', duration:'50-65 days', yield:'40-60 Qtl/acre', price:'₹20-30/kg', spacing:'45×25 cm' },
  { name:'Spinach', emoji:'🥬', type:'vegetable', soil:['loamy','clay'], season:'rabi', water:'medium', duration:'30-45 days', yield:'30-50 Qtl/acre', price:'₹15-25/kg', spacing:'30×10 cm' },
  { name:'Cabbage', emoji:'🥬', type:'vegetable', soil:['loamy','clay'], season:'rabi', water:'high', duration:'60-90 days', yield:'80-150 Qtl/acre', price:'₹10-18/kg', spacing:'45×30 cm' },
  { name:'Cauliflower', emoji:'🥦', type:'vegetable', soil:['loamy','clay'], season:'rabi', water:'high', duration:'60-80 days', yield:'80-100 Qtl/acre', price:'₹12-20/kg', spacing:'45×30 cm' },
  { name:'Carrot', emoji:'🥕', type:'vegetable', soil:['sandy','loamy'], season:'rabi', water:'medium', duration:'70-90 days', yield:'60-100 Qtl/acre', price:'₹15-25/kg', spacing:'30×8 cm' },
  { name:'Watermelon', emoji:'🍉', type:'fruit', soil:['sandy','loamy'], season:'zaid', water:'medium', duration:'65-80 days', yield:'80-120 Qtl/acre', price:'₹8-15/kg', spacing:'2.5×1 m' },
  { name:'Muskmelon', emoji:'🍈', type:'fruit', soil:['sandy','loamy'], season:'zaid', water:'medium', duration:'60-70 days', yield:'60-80 Qtl/acre', price:'₹10-20/kg', spacing:'2×1 m' },
  { name:'Pumpkin', emoji:'🎃', type:'vegetable', soil:['loamy','sandy'], season:'kharif', water:'medium', duration:'55-70 days', yield:'80-120 Qtl/acre', price:'₹8-15/kg', spacing:'3×2 m' },
  { name:'Turmeric', emoji:'🌿', type:'cash', soil:['loamy','black'], season:'kharif', water:'high', duration:'8-10 months', yield:'20-30 Qtl/acre', price:'₹100-150/kg', spacing:'45×25 cm' },
  { name:'Chilli', emoji:'🌶️', type:'cash', soil:['loamy','black'], season:'kharif', water:'medium', duration:'90-120 days', yield:'20-30 Qtl/acre (dry)', price:'₹80-120/kg (dry)', spacing:'45×30 cm' },
  { name:'Ginger', emoji:'🫚', type:'cash', soil:['loamy','sandy'], season:'kharif', water:'high', duration:'8-10 months', yield:'20-25 Qtl/acre', price:'₹60-100/kg', spacing:'25×20 cm' },
  { name:'Garlic', emoji:'🧄', type:'cash', soil:['loamy','sandy'], season:'rabi', water:'medium', duration:'90-130 days', yield:'15-20 Qtl/acre', price:'₹60-100/kg', spacing:'15×8 cm' },
  { name:'Banana', emoji:'🍌', type:'fruit', soil:['loamy','black','clay'], season:'perennial', water:'high', duration:'10-15 months', yield:'200-300 Qtl/acre', price:'₹12-20/kg', spacing:'1.8×1.8 m' },
  { name:'Papaya', emoji:'🍑', type:'fruit', soil:['loamy','sandy'], season:'perennial', water:'medium', duration:'9-12 months', yield:'150-250 Qtl/acre', price:'₹8-15/kg', spacing:'2.5×2.5 m' },
];

function renderSeeds(filtered) {
  const grid = document.getElementById('seedGrid');
  const count = document.getElementById('seedResultCount');
  if (!grid) return;
  count.textContent = `Showing ${filtered.length} crops`;
  grid.innerHTML = filtered.map(s => {
    const soilTags = s.soil.map(soil => `<span class="seed-soil-tag">${soil}</span>`).join('');
    const waterClass = `water-${s.water}`;
    return `<div class="seed-card fade-in">
      <div class="seed-card-top">
        <span class="seed-emoji">${s.emoji}</span>
        <div class="seed-name">${s.name}</div>
        <span class="seed-type">${s.type.toUpperCase()}</span>
      </div>
      <div class="seed-card-body">
        <div class="seed-meta">
          <div class="seed-meta-item"><span class="meta-key">Duration</span><span class="meta-val">${s.duration}</span></div>
          <div class="seed-meta-item"><span class="meta-key">Yield</span><span class="meta-val">${s.yield}</span></div>
          <div class="seed-meta-item"><span class="meta-key">Season</span><span class="meta-val">${s.season.charAt(0).toUpperCase()+s.season.slice(1)}</span></div>
          <div class="seed-meta-item"><span class="meta-key">Spacing</span><span class="meta-val">${s.spacing}</span></div>
        </div>
        <div class="seed-soil-tags">${soilTags}</div>
        <div class="seed-price">
          <span class="price">${s.price}</span>
          <span class="water-need ${waterClass}">💧 ${s.water} water</span>
        </div>
      </div>
    </div>`;
  }).join('');
  // Trigger animations
  setTimeout(() => {
    document.querySelectorAll('.seed-card.fade-in').forEach(el => el.classList.add('visible'));
  }, 100);
}

function filterSeeds() {
  const soil = document.getElementById('filterSoil')?.value || 'all';
  const season = document.getElementById('filterSeason')?.value || 'all';
  const water = document.getElementById('filterWater')?.value || 'all';
  const type = document.getElementById('filterType')?.value || 'all';
  const search = (document.getElementById('seedSearch')?.value || '').toLowerCase();

  const filtered = SEEDS.filter(s => {
    if (soil !== 'all' && !s.soil.includes(soil)) return false;
    if (season !== 'all' && s.season !== season) return false;
    if (water !== 'all' && s.water !== water) return false;
    if (type !== 'all' && s.type !== type) return false;
    if (search && !s.name.toLowerCase().includes(search)) return false;
    return true;
  });
  renderSeeds(filtered);
}

// ===== CROP PRODUCTION DATA =====
const CROP_DATA = {
  cereals: [
    { name:'Rice', icon:'🍚', sub:'Oryza sativa', season:'Kharif', soil:'Clay/Loamy', stages:5, activeStages:3, water:'High', npk:'120-60-60 kg/ha', pest:'BPH, Stem Borer', yield:'40-60 Qtl/ha' },
    { name:'Wheat', icon:'🌾', sub:'Triticum aestivum', season:'Rabi', soil:'Loamy/Clay', stages:5, activeStages:2, water:'Medium', npk:'120-60-40 kg/ha', pest:'Rust, Aphids', yield:'40-55 Qtl/ha' },
    { name:'Maize', icon:'🌽', sub:'Zea mays', season:'Kharif', soil:'Loamy/Sandy', stages:5, activeStages:4, water:'Medium', npk:'120-60-40 kg/ha', pest:'FAW, Aphids', yield:'25-35 Qtl/ha' },
    { name:'Bajra', icon:'🌿', sub:'Pennisetum glaucum', season:'Kharif', soil:'Sandy/Loamy', stages:5, activeStages:1, water:'Low', npk:'80-40-40 kg/ha', pest:'Downy Mildew', yield:'10-20 Qtl/ha' },
    { name:'Sugarcane', icon:'🎋', sub:'Saccharum officinarum', season:'Annual', soil:'Loamy/Black', stages:5, activeStages:5, water:'High', npk:'250-60-120 kg/ha', pest:'Borers, Whitefly', yield:'600-700 Qtl/ha' },
  ],
  vegetables: [
    { name:'Tomato', icon:'🍅', sub:'Solanum lycopersicum', season:'Rabi/Kharif', soil:'Loamy/Sandy', stages:5, activeStages:3, water:'Medium', npk:'200-100-100 kg/ha', pest:'TSWV, Aphids', yield:'200-400 Qtl/ha' },
    { name:'Onion', icon:'🧅', sub:'Allium cepa', season:'Rabi', soil:'Loamy/Black', stages:5, activeStages:2, water:'Medium', npk:'100-50-50 kg/ha', pest:'Thrips, Purple Blotch', yield:'200-250 Qtl/ha' },
    { name:'Potato', icon:'🥔', sub:'Solanum tuberosum', season:'Rabi', soil:'Sandy/Loamy', stages:5, activeStages:4, water:'Medium', npk:'180-80-100 kg/ha', pest:'Late Blight, Aphids', yield:'250-400 Qtl/ha' },
    { name:'Brinjal', icon:'🍆', sub:'Solanum melongena', season:'Kharif', soil:'Loamy/Clay', stages:5, activeStages:3, water:'Medium', npk:'150-75-75 kg/ha', pest:'Shoot Borer, Spider Mite', yield:'200-250 Qtl/ha' },
    { name:'Okra', icon:'🫑', sub:'Abelmoschus esculentus', season:'Kharif', soil:'Loamy/Sandy', stages:5, activeStages:2, water:'Medium', npk:'120-60-40 kg/ha', pest:'Jassids, Yellow Vein Mosaic', yield:'100-150 Qtl/ha' },
    { name:'Cabbage', icon:'🥬', sub:'Brassica oleracea', season:'Rabi', soil:'Loamy/Clay', stages:5, activeStages:1, water:'High', npk:'200-100-100 kg/ha', pest:'Diamond Back Moth', yield:'200-300 Qtl/ha' },
  ],
  fruits: [
    { name:'Mango', icon:'🥭', sub:'Mangifera indica', season:'Perennial', soil:'Loamy/Sandy', stages:5, activeStages:4, water:'Low-Med', npk:'500-250-500 g/tree', pest:'Mango Hopper, Mealybug', yield:'2-3 Tonne/tree/yr' },
    { name:'Banana', icon:'🍌', sub:'Musa acuminata', season:'Perennial', soil:'Loamy/Black', stages:5, activeStages:3, water:'High', npk:'200-60-300 g/plant', pest:'Sigatoka, Wilt', yield:'25-45 Tonne/ha' },
    { name:'Papaya', icon:'🍑', sub:'Carica papaya', season:'Perennial', soil:'Loamy/Sandy', stages:5, activeStages:2, water:'Medium', npk:'200-200-250 g/plant', pest:'Ring Spot Virus, Aphids', yield:'40-60 Tonne/ha' },
    { name:'Watermelon', icon:'🍉', sub:'Citrullus lanatus', season:'Zaid', soil:'Sandy/Loamy', stages:5, activeStages:3, water:'Medium', npk:'100-50-50 kg/ha', pest:'Red Pumpkin Beetle', yield:'200-300 Qtl/ha' },
  ],
  pulses: [
    { name:'Tur (Arhar)', icon:'🫘', sub:'Cajanus cajan', season:'Kharif', soil:'Black/Loamy', stages:5, activeStages:2, water:'Low', npk:'20-50-0 kg/ha', pest:'Pod Borer, Wilt', yield:'8-12 Qtl/ha' },
    { name:'Chana', icon:'🫘', sub:'Cicer arietinum', season:'Rabi', soil:'Loamy/Black', stages:5, activeStages:1, water:'Low', npk:'20-40-0 kg/ha', pest:'Pod Borer, Wilt', yield:'10-15 Qtl/ha' },
    { name:'Moong', icon:'🫛', sub:'Vigna radiata', season:'Zaid', soil:'Loamy/Sandy', stages:5, activeStages:3, water:'Low', npk:'20-40-20 kg/ha', pest:'Yellow Mosaic, Aphids', yield:'6-8 Qtl/ha' },
    { name:'Urad', icon:'🫘', sub:'Vigna mungo', season:'Kharif', soil:'Loamy/Black', stages:5, activeStages:2, water:'Low', npk:'20-40-20 kg/ha', pest:'Yellow Mosaic, Thrips', yield:'6-8 Qtl/ha' },
  ],
  oilseeds: [
    { name:'Groundnut', icon:'🥜', sub:'Arachis hypogaea', season:'Kharif', soil:'Sandy/Loamy', stages:5, activeStages:4, water:'Medium', npk:'25-50-75 kg/ha', pest:'Tikka, Aphids', yield:'20-25 Qtl/ha' },
    { name:'Soybean', icon:'🫛', sub:'Glycine max', season:'Kharif', soil:'Black/Loamy', stages:5, activeStages:3, water:'Medium', npk:'30-60-40 kg/ha', pest:'Girdle Beetle, Pod Borer', yield:'15-20 Qtl/ha' },
    { name:'Mustard', icon:'🌼', sub:'Brassica juncea', season:'Rabi', soil:'Loamy/Sandy', stages:5, activeStages:2, water:'Low', npk:'80-40-40 kg/ha', pest:'Aphids, Alternaria', yield:'10-15 Qtl/ha' },
    { name:'Sunflower', icon:'🌻', sub:'Helianthus annuus', season:'Rabi', soil:'Loamy/Black', stages:5, activeStages:1, water:'Medium', npk:'80-60-40 kg/ha', pest:'Head Rot, Aphids', yield:'8-12 Qtl/ha' },
    { name:'Cotton', icon:'🌸', sub:'Gossypium hirsutum', season:'Kharif', soil:'Black/Loamy', stages:5, activeStages:3, water:'Medium', npk:'150-60-60 kg/ha', pest:'Bollworm, Whitefly', yield:'15-20 Qtl/ha' },
  ]
};

function showCropTab(category, btn) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  const items = CROP_DATA[category] || [];
  const container = document.getElementById('cropContent');
  if (!container) return;
  container.innerHTML = `<div class="crop-content-grid">${items.map(crop => {
    const stageBlocks = Array(crop.stages).fill(0).map((_,i) =>
      `<div class="stage-block ${i < crop.activeStages ? 'active' : ''}"></div>`
    ).join('');
    return `<div class="crop-item">
      <div class="crop-item-header">
        <span class="crop-item-icon">${crop.icon}</span>
        <div><h4>${crop.name}</h4><span>${crop.sub}</span></div>
      </div>
      <div class="crop-details-row"><span>Season:</span><strong>${crop.season}</strong></div>
      <div class="crop-details-row"><span>Soil:</span><strong>${crop.soil}</strong></div>
      <div class="crop-details-row"><span>Water:</span><strong>${crop.water}</strong></div>
      <div class="crop-details-row"><span>NPK:</span><strong>${crop.npk}</strong></div>
      <div class="crop-details-row"><span>Main Pest:</span><strong>${crop.pest}</strong></div>
      <div class="crop-details-row"><span>Avg. Yield:</span><strong>${crop.yield}</strong></div>
      <div class="crop-stages">
        <small style="color:#888">Growth Progress</small>
        <div class="crop-stages-bar">${stageBlocks}</div>
      </div>
    </div>`;
  }).join('')}</div>`;
}

// ===== PEST DATA =====
const PESTS = [
  { icon:'🦗', name:'Brown Plant Hopper', severity:'high', affects:'Rice', info:'Sucks plant sap causing drying of plants (hopper burn). Spreads rapidly in humid conditions.',
    symptoms:['Circular patches of dried plants','Sticky honeydew on leaves','Foul smell from field'],
    treatment:'Apply Buprofezin 25% SC @ 1.25 ml/litre or Imidacloprid 17.8% SL @ 0.25 ml/litre.' },
  { icon:'🐛', name:'Stem Borer', severity:'high', affects:'Rice, Maize', info:'Larvae bore into stem causing "dead heart" in vegetative and "white ear" in reproductive stage.',
    symptoms:['Dead heart in young plants','White ears at heading','Boreholes on stem'],
    treatment:'Use Chlorpyrifos 2.5% DP @ 10 kg/ha or Cartap Hydrochloride 4G @ 10 kg/ha.' },
  { icon:'🦟', name:'Aphids', severity:'medium', affects:'Wheat, Mustard, Vegetables', info:'Suck plant sap. Transmit viral diseases. Found in colonies on undersides of leaves.',
    symptoms:['Curling of leaves','Yellow discoloration','Sticky honeydew on plant surface'],
    treatment:'Spray Dimethoate 30% EC @ 1.5 ml/litre or Imidacloprid 200 SL @ 0.25 ml/litre.' },
  { icon:'🐌', name:'Fall Armyworm (FAW)', severity:'high', affects:'Maize', info:'Highly destructive pest. Can destroy entire maize crop. Identified by inverted "Y" on head.',
    symptoms:['Windowpane feeding on leaves','Ragged leaf damage','Black frass in leaf whorl'],
    treatment:'Apply Emamectin Benzoate 5% SG @ 0.4 g/litre or Spinetoram 11.7% SC @ 0.5 ml/litre.' },
  { icon:'🦋', name:'Bollworm Complex', severity:'high', affects:'Cotton', info:'Most damaging pest of cotton. Bores into bolls, causing shedding and yield loss.',
    symptoms:['Entry holes in bolls','Dried and fallen bolls','Larvae inside bolls'],
    treatment:'Spray Profenophos 50% EC @ 2 ml/litre or Cypermethrin 25% EC @ 0.5 ml/litre.' },
  { icon:'🍄', name:'Late Blight (Fungal)', severity:'high', affects:'Potato, Tomato', info:'Caused by Phytophthora infestans. Spreads rapidly in cool, moist conditions.',
    symptoms:['Water-soaked lesions on leaves','White fluffy growth on underside','Brown rotten tubers'],
    treatment:'Apply Mancozeb 75% WP @ 2.5 g/litre or Metalaxyl-M + Mancozeb @ 2 g/litre.' },
  { icon:'🦗', name:'Locust', severity:'high', affects:'All Crops', info:'Swarms can destroy fields within minutes. Government monitoring available via NCIPM.',
    symptoms:['Rapid defoliation','Dark clouds of insects','Complete crop loss in patches'],
    treatment:'Aerial/ground spraying of Malathion 96% ULV @ 75 ml/ha. Contact Dept. of Agriculture immediately.' },
  { icon:'🌿', name:'Powdery Mildew', severity:'medium', affects:'Wheat, Grapes, Vegetables', info:'Fungal disease causing white powdery coating. Reduces photosynthesis.',
    symptoms:['White powder on leaves','Yellowing and drying','Stunted growth'],
    treatment:'Spray Sulphur 80% WP @ 2.5 g/litre or Hexaconazole 5% SC @ 1 ml/litre.' },
  { icon:'🦠', name:'Yellow Mosaic Virus', severity:'medium', affects:'Moong, Urad, Soybean', info:'Transmitted by whiteflies. Causes yellow mosaic pattern on leaves reducing yield by 80%.',
    symptoms:['Yellow-green mosaic pattern','Stunted plants','Reduced pod/grain fill'],
    treatment:'Control whitefly vectors with Thiamethoxam 25% WG @ 0.3 g/litre. Remove infected plants.' },
  { icon:'🐛', name:'Diamond Back Moth', severity:'medium', affects:'Cabbage, Cauliflower', info:'Most destructive pest of cruciferous vegetables. Larvae feed on leaf tissue.',
    symptoms:['Small holes in leaves','Windowing effect on leaves','Skeletonized leaves'],
    treatment:'Apply Spinosad 45% SC @ 0.15 ml/litre or Chlorfenapyr 10% SC @ 1.5 ml/litre.' },
  { icon:'🍂', name:'Rust Disease', severity:'medium', affects:'Wheat, Sorghum', info:'Fungal disease causing orange/brown pustules on leaves and stems.',
    symptoms:['Orange-brown pustules on leaves','Yellowing and drying','Reduced grain fill'],
    treatment:'Spray Propiconazole 25% EC @ 1 ml/litre or Tebuconazole 25.9% EC @ 1 ml/litre.' },
  { icon:'🦟', name:'Thrips', severity:'low', affects:'Onion, Chilli, Cotton', info:'Tiny insects that scrape leaf surface and suck sap. Transmit Tomato Spotted Wilt Virus.',
    symptoms:['Silver streaks on leaves','Curling of leaf tips','Distorted growth'],
    treatment:'Apply Spinosad 45% SC @ 0.15 ml/litre or Fipronil 5% SC @ 1.5 ml/litre.' },
];

const PESTICIDES = [
  { name:'Chlorpyrifos 20% EC', use:'Controls stem borers, termites, soil insects in rice, cotton, sugarcane', dose:'Dose: 2.5 ml/litre of water or 3 litre/acre mixed with soil', caution:'Pre-harvest interval: 15 days. Do not apply near water bodies.' },
  { name:'Mancozeb 75% WP', use:'Broad-spectrum fungicide for blight, rust, downy mildew in potato, tomato, grapes', dose:'Dose: 2.5 g/litre of water', caution:'Do not apply within 5 days of harvest. Wear gloves and mask.' },
  { name:'Imidacloprid 17.8% SL', use:'Systemic insecticide for aphids, hoppers, thrips, whiteflies in various crops', dose:'Dose: 0.25–0.5 ml/litre of water. Seed treatment: 5–7 ml/kg seed', caution:'Highly toxic to bees. Avoid spraying on flowering crops.' },
  { name:'Propiconazole 25% EC', use:'Systemic fungicide for rust, sheath blight in wheat, rice, sorghum', dose:'Dose: 1 ml/litre of water. Apply at first disease appearance', caution:'PHI: 14 days. Avoid contact with eyes and skin.' },
  { name:'Emamectin Benzoate 5%', use:'Controls caterpillars, leaf miners, Fall Armyworm in maize, vegetables', dose:'Dose: 0.4 g/litre of water', caution:'PHI: 3-7 days. Avoid mixing with alkaline solutions.' },
  { name:'Carbendazim 50% WP', use:'Systemic fungicide for sheath blight, wilt, powdery mildew in vegetables, cereals', dose:'Dose: 1 g/litre of water', caution:'PHI: 7 days. Avoid repeated use to prevent resistance.' },
  { name:'Urea (46% N)', use:'Nitrogen fertilizer for all crops. Promotes vegetative growth and green color', dose:'Dose: As per soil test. General: 120–250 kg/ha split in 2–3 doses', caution:'Do not apply in standing water. Avoid excessive use — leads to lodging.' },
  { name:'DAP (18:46:0)', use:'Di-Ammonium Phosphate. Provides N and P at sowing. Ideal basal fertilizer', dose:'Dose: 100–150 kg/ha at sowing time', caution:'Store in dry place. Do not mix with alkaline fertilizers like SSP or Urea.' },
];

function renderPests() {
  const grid = document.getElementById('pestGrid');
  if (!grid) return;
  grid.innerHTML = PESTS.map(p => `
    <div class="pest-card ${p.severity}">
      <div class="pest-header">
        <span class="pest-icon">${p.icon}</span>
        <div>
          <div class="pest-name">${p.name}</div>
          <span class="pest-severity severity-${p.severity}">${p.severity.toUpperCase()} RISK</span>
          <div style="font-size:0.72rem;color:#888;margin-top:2px">Affects: ${p.affects}</div>
        </div>
      </div>
      <p class="pest-info">${p.info}</p>
      <div class="pest-symptoms">
        <strong>Symptoms:</strong>
        <ul>${p.symptoms.map(s => `<li>${s}</li>`).join('')}</ul>
      </div>
      <div class="pest-treatment">
        <strong>Treatment:</strong>
        <p>${p.treatment}</p>
      </div>
    </div>`).join('');

  const pestGrid = document.getElementById('pesticideGrid');
  if (!pestGrid) return;
  pestGrid.innerHTML = PESTICIDES.map(p => `
    <div class="pesticide-card">
      <h4>${p.name}</h4>
      <p class="p-use">${p.use}</p>
      <div class="p-dose"><i class="fas fa-flask" style="color:#2e7d32;margin-right:5px"></i>${p.dose}</div>
      <p class="p-caution">⚠️ ${p.caution}</p>
    </div>`).join('');
}

// ===== IRRIGATION TABLE =====
const IRRIG_DATA = [
  { crop:'🌾 Wheat', freq:'6-8 times', method:'Sprinkler/Furrow', stage:'Crown Root Initiation (21 days after sowing)' },
  { crop:'🍚 Rice', freq:'Continuous flooding', method:'Flood/Drip (SRI)', stage:'Transplanting & Panicle Initiation' },
  { crop:'🌽 Maize', freq:'5-6 times', method:'Drip/Furrow', stage:'Knee-high stage & Silking' },
  { crop:'🍅 Tomato', freq:'Every 3-4 days', method:'Drip Irrigation', stage:'Flowering & Fruit Development' },
  { crop:'🧅 Onion', freq:'Every 7-10 days', method:'Sprinkler/Furrow', stage:'Bulb Development' },
  { crop:'🥔 Potato', freq:'Every 8-10 days', method:'Drip/Furrow', stage:'Tuber Initiation (45-60 DAS)' },
  { crop:'🥜 Groundnut', freq:'Every 10-12 days', method:'Drip/Sprinkler', stage:'Pegging & Pod Development' },
  { crop:'🌸 Cotton', freq:'Every 10-15 days', method:'Drip/Furrow', stage:'Boll Formation Stage' },
  { crop:'🎋 Sugarcane', freq:'Every 5-7 days (summer)', method:'Drip/Furrow', stage:'Grand Growth Period' },
  { crop:'🌿 Turmeric', freq:'Every 7-10 days', method:'Drip/Furrow', stage:'Tillering & Rhizome Development' },
];

function renderIrrigTable() {
  const tbody = document.getElementById('irrigTable');
  if (!tbody) return;
  tbody.innerHTML = IRRIG_DATA.map(r => `
    <tr>
      <td>${r.crop}</td>
      <td>${r.freq}</td>
      <td>${r.method}</td>
      <td>${r.stage}</td>
    </tr>`).join('');
}

// ===== QUICK SOIL CHECK =====
const soilCrops = {
  sandy: { crops:'Groundnut, Watermelon, Carrot, Radish, Millet, Mustard, Cucumber, Sweet Potato', note:'Light soil with low fertility. Add compost and use drip irrigation.' },
  clay: { crops:'Rice, Wheat, Cotton, Sugarcane, Cabbage, Lotus', note:'Heavy soil with high water retention. Avoid waterlogging. Deep plough before sowing.' },
  loamy: { crops:'Wheat, Maize, Vegetables, Pulses, Fruits, Oilseeds — almost all crops thrive!', note:'Best all-purpose soil. Ideal for crop rotation and high-value crops.' },
  black: { crops:'Cotton, Soybean, Sunflower, Sorghum, Lentils, Chilli, Turmeric', note:'Rich in calcium. Cracks in summer aid aeration. Add nitrogen fertilizer.' }
};
function quickSoil(type) {
  document.querySelectorAll('.soil-btn').forEach(b => b.classList.remove('active'));
  event.target.classList.add('active');
  const data = soilCrops[type];
  document.getElementById('soilQuickResult').innerHTML = `
    <strong style="color:#2e7d32;display:block;margin-bottom:6px">Recommended Crops:</strong>
    <p style="margin-bottom:6px">${data.crops}</p>
    <p style="font-size:0.78rem;color:#6a7c6a;border-top:1px solid #c8e6c9;padding-top:6px">${data.note}</p>`;
}

// ===== FARMER REGISTRATION =====
let farmers = JSON.parse(localStorage.getItem('farmsmart_farmers') || '[]');

function registerFarmer() {
  const name = document.getElementById('fName')?.value.trim();
  const village = document.getElementById('fVillage')?.value.trim();
  const district = document.getElementById('fDistrict')?.value.trim();
  const state = document.getElementById('fState')?.value;
  const land = document.getElementById('fLand')?.value;
  const soil = document.getElementById('fSoil')?.value;
  const phone = document.getElementById('fPhone')?.value.trim();
  const crop = document.getElementById('fCrop')?.value.trim();

  if (!name || !village || !phone) { alert('Please fill Name, Village and Phone number.'); return; }

  const farmer = { id: Date.now(), name, village, district, state, land, soil, phone, crop, date: new Date().toLocaleDateString('en-IN') };
  farmers.unshift(farmer);
  localStorage.setItem('farmsmart_farmers', JSON.stringify(farmers));
  renderFarmers(farmers);

  // Clear form
  ['fName','fVillage','fDistrict','fLand','fPhone','fCrop'].forEach(id => { if (document.getElementById(id)) document.getElementById(id).value = ''; });
  alert(`✅ ${name} registered successfully!`);
}

function renderFarmers(list) {
  const container = document.getElementById('farmerList');
  if (!container) return;
  if (!list.length) { container.innerHTML = '<p style="color:#aaa;text-align:center;padding:20px">No farmers registered yet.</p>'; return; }
  container.innerHTML = list.map(f => `
    <div class="farmer-item">
      <div class="farmer-avatar">${f.name.charAt(0).toUpperCase()}</div>
      <div class="farmer-info">
        <h4>${f.name}</h4>
        <p>${f.village}, ${f.district || ''} ${f.state}</p>
        <p>${f.phone} | ${f.land} acres | ${f.soil} soil</p>
      </div>
      <div class="farmer-badge">${f.crop || 'Farmer'}</div>
    </div>`).join('');
}

function searchFarmers() {
  const q = (document.getElementById('farmerSearch')?.value || '').toLowerCase();
  const filtered = farmers.filter(f =>
    f.name.toLowerCase().includes(q) ||
    f.village.toLowerCase().includes(q) ||
    (f.crop || '').toLowerCase().includes(q)
  );
  renderFarmers(filtered);
}

// ===== PROFIT CALCULATOR =====
function calcProfit() {
  const crop = document.getElementById('calcCrop')?.value || 'Crop';
  const qty = parseFloat(document.getElementById('calcQty')?.value) || 0;
  const cost = parseFloat(document.getElementById('calcCost')?.value) || 0;
  const sell = parseFloat(document.getElementById('calcSell')?.value) || 0;

  const totalCost = qty * cost;
  const totalRevenue = qty * sell;
  const profit = totalRevenue - totalCost;
  const margin = totalRevenue > 0 ? ((profit / totalRevenue) * 100).toFixed(1) : 0;

  const el = document.getElementById('calcResult');
  if (!el) return;
  el.classList.add('show');
  const color = profit >= 0 ? '#2e7d32' : '#d32f2f';
  el.innerHTML = `
    <strong>${crop} — ${qty} Quintals</strong>
    <div style="margin-top:8px">Total Cost: ₹${totalCost.toLocaleString('en-IN')}</div>
    <div>Total Revenue: ₹${totalRevenue.toLocaleString('en-IN')}</div>
    <div class="profit-num" style="color:${color}">
      ${profit >= 0 ? '✅ Profit' : '❌ Loss'}: ₹${Math.abs(profit).toLocaleString('en-IN')}
    </div>
    <div style="font-size:0.82rem;color:#666">Profit Margin: ${margin}%</div>
    ${profit < 0 ? '<p style="font-size:0.78rem;color:#c62828;margin-top:8px">💡 Consider storage and selling later, or reduce production cost via FPO.</p>' : ''}`;
}

// ===== AI CHATBOT =====
var chatKnowledge = {
  'rice': 'Rice grows best in clay or loamy soil with heavy water. It is a Kharif crop (Jun–Nov). Use paddy varieties like IR-36, Pusa Basmati, or Swarna. Yield: 20–25 qtl/acre. Keep 3–5cm standing water during tillering. Market price: ₹1,940–2,180/qtl (MSP).',
  'wheat': 'Wheat is a Rabi crop (Nov–Apr) that prefers loamy soil and cool temperatures. Varieties: HD-2967, PBW-343, WH-542. Yield: 15–20 qtl/acre. First irrigation at Crown Root Initiation (20–25 days). MSP: ₹2,015–2,275/qtl.',
  'maize': 'Maize grows in almost all soils. Season: Kharif or Rabi. Yield: 20–30 qtl/acre. Apply nitrogen in 3 splits. Hybrid varieties give best results. Price: ₹1,870–2,100/qtl.',
  'cotton': 'Cotton grows best in black soil during Kharif season. BT cotton is widely used. Bollworm and whitefly are major pests. MSP: ₹5,726–7,000/qtl. Harvest in stages.',
  'clay soil': 'Clay soil is heavy, holds water, and is nutrient-rich. Best for rice, wheat, sugarcane, and brinjal. pH: 6.0–7.0. Avoid waterlogging. Use raised beds for vegetables.',
  'sandy soil': 'Sandy soil drains fast and is low in nutrients. Best for groundnut, watermelon, carrot, and sweet potato. Add compost to improve fertility. Irrigate frequently in small quantities.',
  'loamy soil': 'Loamy soil is the ideal farming soil. Perfect for wheat, maize, tomato, onion, and cotton. pH: 6.0–7.0. Maintain with organic matter. Suitable for almost all crops.',
  'black soil': 'Black soil is rich in calcium and magnesium. Best for cotton, soybean, sorghum, and sunflower. pH: 7.5–8.5. Deep and moisture-retaining. Ideal for deep-rooted crops.',
  'stem borer': 'Stem borer is a major pest of rice, sugarcane, and maize. It bores into stems causing dead heart. Treatment: Apply Carbofuran granules (1kg/acre) in leaf whorls. Use Neem-based sprays as eco-friendly option.',
  'aphid': 'Aphids suck sap from leaves causing yellowing. They attack mustard, vegetables, and pulses. Treatment: Imidacloprid 0.5ml/L water, Neem oil 5ml/L, or strong water spray to dislodge them.',
  'fungal': 'Fungal diseases show as brown/black spots, powdery coating, or wilting. Treatment: Mancozeb 2.5g/L for blight, Sulfur-based spray for powdery mildew. Avoid waterlogging and improve air circulation.',
  'kharif': 'Kharif crops are sown in June–July and harvested in Oct–Nov. Major crops: Rice, Maize, Cotton, Soybean, Bajra, Groundnut, Sugarcane, Moong, Urad. These crops need monsoon rainfall.',
  'rabi': 'Rabi crops are sown in Oct–Nov and harvested in Mar–Apr. Major crops: Wheat, Mustard, Chickpea, Lentil, Barley, Pea, Cumin, Coriander. These crops need cool weather and moderate irrigation.',
  'zaid': 'Zaid crops are grown in April–June between Rabi and Kharif. Major crops: Watermelon, Muskmelon, Cucumber, Pumpkin, Moong Dal. These are short-duration crops needing warm weather.',
  'drip irrigation': 'Drip irrigation delivers water directly to plant roots through small tubes. It saves 40–70% water compared to flood irrigation. Ideal for vegetables, fruit crops, and areas with water scarcity. Initial cost is high but saves water and fertilizer.',
  'msp': 'Minimum Support Price (MSP) is the price set by the government to protect farmers from low market prices. Key MSPs 2024: Wheat ₹2,275/qtl, Rice ₹2,183/qtl, Cotton ₹7,020/qtl, Mustard ₹5,650/qtl. Check CACP website for latest values.',
  'water': 'Water saving tips: Use drip or sprinkler irrigation. Irrigate in the morning or evening. Mulch the field to reduce evaporation. Grow drought-tolerant varieties. Check soil moisture before irrigating. Collect rainwater in farm ponds.',
  'tomato': 'Tomato grows in loamy soil year-round (best Oct–Feb). Transplant at 35–40 days. Stake plants for support. Remove suckers. Major pests: Early blight, Late blight, Leaf curl virus. Yield: 120–200 qtl/acre. Market price: ₹500–3,000/qtl.',
  'onion': 'Onion needs sandy loam soil. Transplant at 6–8 weeks. Reduce irrigation 10 days before harvest. Storage life is 4–6 months. Best market price in May–June. Yield: 80–100 qtl/acre.',
  'potato': 'Potato grows in Rabi season (Oct–Mar) in loamy soil. Use certified seed tubers. Earth up at 30–35 days. Major disease: Late blight — spray Mancozeb preventively. Yield: 80–120 qtl/acre.',
  'urea': 'Urea is a nitrogen fertilizer (46% N). Apply in splits: 25% at sowing, 50% at active growth, 25% before flowering. Standard rate: 25–50 kg/acre depending on crop. Excess urea damages soil and reduces quality.',
  'neem': 'Neem-based pesticides are organic and eco-friendly. Neem oil (5ml/L water) controls aphids, mites, and fungal issues. Neem cake used as soil amendment also repels nematodes. Safe for humans and beneficial insects.'
};

function sendChat() {
  var input = document.getElementById('chatInput');
  var msg = input.value.trim();
  if (!msg) return;
  input.value = '';
  appendMsg('user', '👤', msg);
  appendTyping();
  setTimeout(function () {
    removeTyping();
    var reply = getChatReply(msg);
    appendMsg('bot', '🌾', reply);
    scrollChat();
  }, 900 + Math.random() * 600);
}

function askQuick(msg) {
  document.getElementById('chatInput').value = msg;
  sendChat();
}

function getChatReply(msg) {
  var lower = msg.toLowerCase();
  for (var key in chatKnowledge) {
    if (lower.indexOf(key) !== -1) return chatKnowledge[key];
  }
  // Topic-based responses
  if (lower.indexOf('soil') !== -1) return 'There are 4 main soil types: Sandy (best for groundnut, watermelon), Clay (best for rice, wheat), Loamy (best for all crops — the ideal soil!), and Black soil (best for cotton, soybean). Use the Soil Analyzer in the Soil section above to get specific recommendations!';
  if (lower.indexOf('seed') !== -1) return 'We have 120+ seeds in our database! Categories: Cereals (rice, wheat, maize), Pulses (chana, moong, arhar), Oilseeds (mustard, groundnut, soybean), Spices (cumin, chilli, turmeric), and Cash crops (cotton, sugarcane). Check the Seeds section for full details!';
  if (lower.indexOf('weather') !== -1) return 'Go to the Weather section and enter your city to get real-time weather data and farming advice! Hot weather (>35°C) requires morning/evening irrigation. Rainy days are great for transplanting. Cool weather is perfect for Rabi crops.';
  if (lower.indexOf('price') !== -1 || lower.indexOf('market') !== -1) return 'Check the Market Prices section above for live mandi rates for all major crops! Always compare with MSP before selling. Use eNAM (enam.gov.in) or AgriMarket app for better price discovery. Direct selling to mandi avoids middlemen.';
  if (lower.indexOf('pest') !== -1 || lower.indexOf('disease') !== -1 || lower.indexOf('insect') !== -1) return 'Common agricultural pests include Stem Borer, Aphids, Bollworms, Locust swarms, Red Spider Mites, and fungal diseases like Blight and Powdery Mildew. Check the Pest Control section above for specific treatments! For organic control, use Neem oil (5ml/L water).';
  if (lower.indexOf('fertilizer') !== -1 || lower.indexOf('nutrition') !== -1) return 'Key fertilizers: Urea (Nitrogen), DAP (Phosphorus+Nitrogen), MOP (Potassium). Use NPK ratio based on soil test. Organic options: FYM (Farm Yard Manure), Compost, Green Manure, Vermicompost. Never apply excess urea as it damages soil structure.';
  if (lower.indexOf('hello') !== -1 || lower.indexOf('hi') !== -1 || lower.indexOf('namaste') !== -1) return 'Namaste! 🙏 Welcome to FarmSeed AI Assistant. I can help you with seed selection, soil types, pest control, weather guidance, market prices, fertilizers, and all farming queries. What would you like to know?';
  if (lower.indexOf('help') !== -1) return 'I can answer questions about: 🌾 Seed selection by soil/season, 🌍 Soil types and testing, 🌤️ Weather farming advice, 📈 Market prices and MSP, 🐛 Pest and disease control, 💧 Irrigation methods, 💊 Fertilizers and pesticides. Just type your question!';
  return 'That is a great farming question! I can help you with seeds, soil types, crop selection, pest control, weather tips, and market prices. Could you be more specific? For example: "Which seeds grow in clay soil?" or "How to control leaf blight in tomato?" You can also check our Seeds, Soil, and Pest sections above for detailed information.';
}

function appendMsg(type, avatar, text) {
  var win = document.getElementById('chatWindow');
  var div = document.createElement('div');
  div.className = 'chat-msg ' + type;
  div.innerHTML = '<div class="chat-avatar">' + avatar + '</div><div class="chat-bubble">' + text + '</div>';
  win.appendChild(div);
  scrollChat();
}

function appendTyping() {
  var win = document.getElementById('chatWindow');
  var div = document.createElement('div');
  div.className = 'chat-msg bot chat-typing';
  div.id = 'typingIndicator';
  div.innerHTML = '<div class="chat-avatar">🌾</div><div class="chat-bubble"><span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span></div>';
  win.appendChild(div);
  scrollChat();
}

function removeTyping() {
  var t = document.getElementById('typingIndicator');
  if (t) t.remove();
}

function scrollChat() {
  var win = document.getElementById('chatWindow');
  win.scrollTop = win.scrollHeight;
}


// ===== SCROLL ANIMATIONS =====
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
    }
  });
}, { threshold: 0.1 });

function initAnimations() {
  document.querySelectorAll('.soil-card, .water-card, .pest-card, .crop-item').forEach(el => {
    el.classList.add('fade-in');
    observer.observe(el);
  });
}

// ===== LIVE PRICE REFRESH =====
setInterval(() => {
  updateMarketPrices();
  renderMarketTable();
  renderBigMarketTable(
    document.getElementById('mktSearch')?.value || '',
    document.getElementById('mktCategory')?.value || 'all'
  );
}, 8000);

// ===== INIT ALL =====
window.addEventListener('DOMContentLoaded', () => {
  updateClock();
  initWeather();
  updateMarketPrices();
  renderMarketTable();
  renderBigMarketTable();
  filterSeeds();
  showCropTab('cereals', document.querySelector('.tab-btn'));
  renderPests();
  renderIrrigTable();
  renderFarmers(farmers);
  initAnimations();

  // Close nav on link click (mobile)
  document.querySelectorAll('.nav-links a').forEach(a => {
    a.addEventListener('click', () => document.getElementById('navLinks').classList.remove('open'));
  });
});